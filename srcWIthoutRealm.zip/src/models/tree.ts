import {createRealmContext} from '@realm/react';
import Realm from 'realm';

// Define a class representing the structure of your data
export class Tree extends Realm.Object {
  _id!: Realm.BSON.ObjectId;
  sapling_id!: string;
  tree_id!: Realm.BSON.ObjectId;
  plot_id!: Realm.BSON.ObjectId;
  user_id!: Realm.BSON.ObjectId;
  image!: string[];
  height?: number;
  date_added?: Date;
  tags!: string[];
  location!: {type: string; coordinates: [number, number]};
  mapped_to!: Realm.BSON.ObjectId;
  link?: string;
  event_type?: string;
  desc?: string;
  date_assigned?: Date;

  // Define a Realm schema for your data
  static treeSchema = {
    name: 'Trees',
    primaryKey: '_id',
    properties: {
      _id: 'objectId',
      sapling_id: {type: 'string', indexed: true, unique: true},
      tree_id: 'objectId',
      plot_id: 'objectId',
      user_id: 'objectId',
      image: 'string[]',
      height: {type: 'int', optional: true},
      date_added: {type: 'date', optional: true},
      tags: 'string[]',
      location: {
        type: 'object',
        properties: {type: 'string', coordinates: 'double[]'},
      },
      mapped_to: 'objectId',
      link: {type: 'string', optional: true},
      event_type: {type: 'string', optional: true},
      desc: {type: 'string', optional: true},
      date_assigned: {type: 'date', optional: true},
    },
  };
}

// Define a Realm context for your data
export const RealmContext = createRealmContext({
  schema: [Tree],
});
