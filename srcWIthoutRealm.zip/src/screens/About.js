// add tree screen

import React, {useEffect} from 'react';
// import * as ImagePicker from 'react-native-image-picker';
import {
  Text,
  Image,
  View,
} from 'react-native';

const About = ({navigation}) => {
 
  return (
    <View
      style={{backgroundColor: 'white', padding: 40, alignItems: 'center'}}>
      <Text
        style={{
          color: '#0F4334',
          fontSize: 22,
          fontWeight: 'bold',
          paddingBottom: 5,
        }}>
        Sapling Upload App
      </Text>
      <Text style={{color: '#0F4334', fontSize: 18,paddingBottom:15}}>Version 2.1</Text>
      <View>
        <Image
          source={require('../../assets/logo.png')} 
          style={{width: 100, height: 100, }} 
        />
      </View>
      <Text style={{color: '#0F4334', fontSize: 18,padding:15}}>14 Trees Org.</Text>
    </View>
  );
};

export default About;
