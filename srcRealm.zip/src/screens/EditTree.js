import React, {useState, useEffect, useContext} from 'react';
import {
  Button,
  StyleSheet,
  Text,
  TextInput,
  ToastAndroid,
  View,
  BackHandler,
  TouchableOpacity,
} from 'react-native';
import {DataService} from '../services/DataService';
import {Strings} from '../services/Strings';
import {TreeForm, treeFormModes} from '../components/TreeForm';
import {Constants, Utils} from '../services/Utils';
import {commonStyles} from '../services/Styles';
import LangContext from '../context/LangContext ';
import {
  trees,
  RealmContext,
  plots,
  tree_types,
} from '../models/Tree';
import {BSON} from 'realm';


const {useRealm,useQuery} = RealmContext;
const realm = useRealm();



//Realm.open({trees});

const EditTreeScreen = ({navigation}) => {
  
     //const realm = realmRef.current
    //  const treesUsingRef = realm.objects('trees')
    // console.log("-------------treesUsingRef------------",treesUsingRef)

  const [saplingid, setSaplingid] = useState('');
  const [details, setDetails] = useState(null);
  const [newImages, setNewImages] = useState([]);
  const [deletedImages, setDeletedImages] = useState([]);
  const {langChanged} = useContext(LangContext);

  const atlastreesArray = useQuery(trees);
  const treesObjects = realm.objects('trees')
  console.log("-------------in Edit tree screen--------",treesObjects.length,atlastreesArray.length)
//   useEffect(() => {
//     setTreesObjects(treesInRealm)
//   },[treesInRealm]);



  useEffect(() => {
    const backAction = () => {
      navigation.goBack();
      return true; // Prevent default behavior (exit app)
    };

    const backHandler = BackHandler.addEventListener(
      'hardwareBackPress',
      backAction,
    );

    return () => backHandler.remove();
  }, []);

  useEffect(() => {
    console.log('langChanged inside EditTreeScreen: ', langChanged);
  }, [langChanged]);

  const updateDetails = async (tree, images) => {
    console.log('tree details from edit----', tree);
    //console.log("images details from edit----",  images);

    const saplingData = {
      location: {
        type: 'Point',
        coordinates: [0, 0],
      },
      sapling_id: '',
      image: details.inImages.map(image => image.name),
      tree_id: '', //tree type id.
      plot_id: '', //plot id
    };
    const adminID = await Utils.getAdminId();
    console.log('adminID inside edit tree screen----', adminID);
    saplingData.location.coordinates = [tree.lat, tree.lng];
    saplingData.sapling_id = tree.saplingid;
    saplingData.plot_id = tree.plotid;
    saplingData.tree_id = tree.treeid; //tree type.

    for (let image of images) {
      let newImageIndex = newImages.findIndex(item => item.name === image.name);
      if (newImageIndex !== -1) {
        newImages[newImageIndex].meta.remark = image.meta.remark;
        setNewImages(newImages);
      }
    }

    let newImagesArr = newImages.slice(-1);

    const requestData = {
      data: saplingData,
      newImages: newImagesArr,
      deletedImages: deletedImages,
    };

    console.log(
      'new images: ',
      newImagesArr.length,
      'deleted images: ',
      deletedImages.length,
    );
    //console.log("new images: ", newImages);
    //console.log("new last images: ", newImages[newImages.length - 1]);
    const response = await DataService.updateSapling(adminID, requestData);
    if (!response) {
      return;
    }
    //console.log(requestData);
    let toastmsg =
      Strings.alertMessages.TreeUpdatedfirsthalf +
      response.data.sapling_id +
      Strings.alertMessages.TreeUpdatedsecondhalf;
    ToastAndroid.show(toastmsg, ToastAndroid.LONG);
    setDetails(null);
    setNewImages([]);
    setDeletedImages([]);

    //Format saplingData using tree,newIamges, deletedImages.
    // Dataservice.updateSapling call...
    // check reply.
  };

  const fetchTreeDetails = async () => {
    const adminID = await Utils.getAdminId();
    console.log(adminID);
    setDetails(null);
    setNewImages([]);
    setDeletedImages([]);

    // const treeDetails = treesObjects.find(
    //   tree => tree.sapling_id === saplingid,
    // );

    //fetching remote tree details
    const treeDetails = await DataService.fetchTreeDetails(saplingid, adminID);
    
    if (!treeDetails) {
      return;
    }
    const detailsForTreeForm = {...Constants.treeFormTemplateData};

    // const treeType = await Utils.treeTypeFromObjectID(treeDetails.tree_id);
    // const plot = await Utils.plotFromObjectID(treeDetails.plot_id);
    //---------------------------------------------------------------
    const treeType = await Utils.treeTypeFromID(treeDetails.tree_id);
    const plot = await Utils.plotFromPlotID(treeDetails.plot_id);
    console.log("------------treeType-------plot---------",treeType,plot)

    detailsForTreeForm.inImages = treeDetails.image; //TODO: server should return:
    
    for (let image of detailsForTreeForm.inImages) {
    //   console.log('-----------image data-----------------', image.data);
      image.data = await DataService.fileURLToBase64(image.name);
    }

    detailsForTreeForm.inLat = 0;
    detailsForTreeForm.inLng = 0;
    if (treeDetails.location) {
      detailsForTreeForm.inLat = treeDetails.location.coordinates[0];
      detailsForTreeForm.inLng = treeDetails.location.coordinates[1];
    }
    detailsForTreeForm.inSaplingId = treeDetails.sapling_id;
    detailsForTreeForm.inTreeType = treeType;
    detailsForTreeForm.inPlot = plot;
    detailsForTreeForm.inUserId = treeDetails.user_id;
    // console.log(detailsForTreeForm);
    setDetails(detailsForTreeForm);
  };

  if (details) {
    return (
      <TreeForm
        mode={treeFormModes.remoteEdit}
        treeData={details}
        onCancel={() => setDetails(null)}
        updateUserId={false}
        updateLocation={false}
        onVerifiedSave={updateDetails}
        onNewImage={image => {
          setNewImages([...newImages, image]);
        }}
        onDeleteImage={name => {
          setDeletedImages([...deletedImages, name]);
        }}
      />
    );
  } else {
    return (
      <View style={{backgroundColor: 'white', height: '100%'}}>
        <View
          style={{backgroundColor: '#0F4334', margin: 10, borderRadius: 10}}>
          <Text
            style={{color: 'white', marginLeft: 20, margin: 10, fontSize: 18}}>
            {Strings.messages.EnterSaplingId}
          </Text>
          <TextInput
            style={commonStyles.txtInput}
            placeholder={Strings.labels.SaplingId}
            placeholderTextColor={'black'}
            onChangeText={text => setSaplingid(text)}
            value={saplingid}
          />
          <View style={{margin: 20}}>
            <TouchableOpacity
              style={commonStyles.searchButton}
              onPress={() => fetchTreeDetails()}>
              <Text style={{color: 'white', fontSize: 18, fontWeight: 'bold'}}>
                {Strings.buttonLabels.Search}
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    );
  }
};

export default EditTreeScreen;
