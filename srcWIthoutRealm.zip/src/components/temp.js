



<View style={{ marginHorizontal: 20, marginTop: 10, marginBottom: 15, opacity: (mode === treeFormModes.remoteEdit && disableButton) ? 0.5 : 1, }}>
    <TouchableOpacity 
        style={{
            backgroundColor: (mode === treeFormModes.remoteEdit && disableButton) ? "#696969" : "#1A894E",
            padding: 10, borderColor: "white",
            borderRadius: 5, alignItems: "center", borderWidth: 1, marginTop: 0
        }} 
        onPress={() => {
            if (mode === treeFormModes.remoteEdit && disableButton) {
                ToastAndroid.show(Strings.alertMessages.deleteImageEdit, ToastAndroid.SHORT);
            } else {
                setModalVisible(true);
            }
        }}>
        
        <Text style={{ color: "white", fontWeight: 'bold', fontSize: 17 }}>{Strings.buttonLabels.ClickPhoto}</Text>


    </TouchableOpacity>

</View>